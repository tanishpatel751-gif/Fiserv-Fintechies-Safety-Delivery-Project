# Bank Safety Deposit Box Delivery:

# Ideation:

Started off talking about multifactor authentication box for securing personal items. Then we thought about how that could be used by banks in safety deposit boxes. We found ways to innovate on this idea which you can find below 

# Tech and Materials:

- Raspberry Pi
- Electronic Sensors(Infrared sensor, Thumbprint sensor, Arduino)
- Finch Robots
- Google Teachable machine

# Mechanical Brainstorming:

Route Brain storming: 

![WIN_20260131_17_24_21_Pro.jpg](WIN_20260131_17_24_21_Pro.jpg)

What this picture is trying to show is that layer of storage for the boxes has its own track that consolidates and goes into one tunnel. The tunnel picks the box off of the finch robot. This is then taken to the elevator where it flips depending on whether the role of the person is a bank employee or bank customer.  

Update: 

I was thinking just 3d print little notches inside for the robot to follow.

# Ideas to Differentiate:

- Glass inside the boxes to redirect light and make sure nobody can see what is inside
- To increase bank incentive to protect these boxes create a separate guarded section inside of them with the money inside of them opened by separate biometric key the bank has. Divide the 250,000 dollars among each of the boxes and this increases incentive of the bank to protect safety deposit boxes
- Use SD cards to store people’s data.

Subsystems: 

- [x]  KeyPad System
- [ ]  LCD Display
- [ ]  Google Teachable machine
- [ ]  Thumbprint sensor
- [ ]  motors

<aside>
💡

So Far I am only working on the part of this architecture to call a robot for an existing user. 

</aside>

```python
# At the point of 2/15/2026 I have to make it all connect together. How? 
#
#
#
```

# Physical Machine

```python
import gpiozero 
import pigpio 
from adafruit_servokit import ServoKit

kit = ServoKit(channels=16) 
#x and y variables represent angles
Xpos= kit.servo[0]
Ypos= kit.servo[1] 
Claw= kit.servo[2]  
#might have to replace with code for the arm robot
openClawdeg= openClaw.angle 
openClawdeg = 60

closeClaw = kit.servo[3] 
closeClawdeg= closeClaw.angle
closeClawdeg = 0 

customerArray = [{"Tanish Patel", 10,20}, {"", 20,30}, {"", 40,20}, {"", 40,30}] 

#Add x-y axis mobility 
def box1_1(): 
   Xpos.angle = customerArray[0][1]
   Ypos.angle = customerArray[0][2]
   Claw.angle= openClawdeg
   time.sleep(1) 
   Claw.angle= closeClawdeg
def box1_2(): 
     Xpos.angle = customerArray[1][1]
     Ypos.angle = customerArray[1][2]
     Claw.angle= openClawdeg
     time.sleep(1) 
     Claw.angle= closeClawdeg
def box2_1(): 
      Xpos.angle = customerArray[2][1]
      Ypos.angle = customerArray[2][2]
      Claw.angle= openClawdeg
      time.sleep(1) 
      Claw.angle= closeClawdeg 
def box2_2(): 
      Xpos.angle = customerArray[3][1]
      Ypos.angle = customerArray[3][2]
      Claw.angle= openClawdeg
      time.sleep(1) 
      Claw.angle= closeClawdeg 
position_list = [box1_1, box1_2, box2_1, box2_2] 
# finding boxes can be hardcoded because there will likely only be four  

```

LCD/ Display:

```python
import os 
import time
from RPLCD.i2c import CharLCD

# Initialize the LCD with its I2C address, port expander (e.g., PCF8574 is default), and I2C bus number (1 for most modern Pis)
lcd = CharLCD(address=0x27, port=1, backlight_enabled=True) 

# Write a message to the display
lcd.write_string("Hello, world!") 

# You can position text with cursor_pos
lcd.cursor_pos = (1, 0) # Line 2, Column 1
lcd.write_string("from Raspberry Pi")

# Keep the message displayed for a few seconds and clear
time.sleep(5)
lcd.clear()
```

```python
from pad4pi import rpi_gpio
import time 

# Define key mapping
KEYPAD = [
    ["1","2","3","A"],
    ["4","5","6","B"],
    ["7","8","9","C"],
    ["*","0","#","D"]
]

# Set up GPIO pins (refer to your wiring)
ROW_PINS = [16, 20, 21, 5] # Example GPIO numbers
COL_PINS = [6, 13, 19, 26] # Example GPIO numbers

factory = rpi_gpio.KeypadFactory()
keypad = factory.create_keypad(keypad=KEYPAD, row_pins=ROW_PINS, col_pins=COL_PINS)

def printKey(key):
    print(key)

# Print key pressed
keypad.registerKeyPressHandler(printKey)

try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    keypad.cleanup()

```

# Bringing the Keypad- LCD Code together:

```python
from pad4pi import rpi_gpio
import time 

# Define key mapping
KEYPAD = [
    ["1","2","3","A"],
    ["4","5","6","B"],
    ["7","8","9","C"],
    ["*","0","#","D"]
]

# Set up GPIO pins (refer to your wiring)
ROW_PINS = [16, 20, 21, 5] # Example GPIO numbers
COL_PINS = [6, 13, 19, 26] # Example GPIO numbers

factory = rpi_gpio.KeypadFactory()
keypad = factory.create_keypad(keypad=KEYPAD, row_pins=ROW_PINS, col_pins=COL_PINS)

passWord = 123A
last_pressed = None
attempt = ""
valid = None
def printKey(key):
    global last_pressed
    last_pressed = key 
    print(key)

# Print key pressed
customKey = keypad.registerKeyPressHandler(printKey)

if printKey: 
    attempt += customKey
if attempt.len() == passWord.len(): 
     if attempt == passWord: 
          print("Password Guessed") 
          valid= "Password Guessed" 
          return true
     else: 
        print("Not Guessed") 
         valid = "Password incorrect" 
         return false 

import time
from RPLCD.i2c import CharLCD

# Initialize the LCD with its I2C address, port expander (e.g., PCF8574 is default), and I2C bus number (1 for most modern Pis)
lcd = CharLCD(address=0x27, port=1, backlight_enabled=True) 

# Write a message to the display

# You can position text with cursor_pos
lcd.cursor_pos = (1, 0) # Line 2, Column 1
lcd.write_string(valid) 

#####################################
#########Here in this part I will add the functionality of the
 # Screen with other parts of the whole project ##########
#####################################

# Keep the message displayed for a few seconds and clear
time.sleep(5)
lcd.clear()

#Put this at the end for data cleanup 
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    keypad.cleanup()
```

# Using Google Teachable Machine

```python
from keras.models import load_model  # TensorFlow is required for Keras to work
from PIL import Image, ImageOps  # Install pillow instead of PIL
import numpy as np

# Disable scientific notation for clarity
np.set_printoptions(suppress=True)

# Load the model
model = load_model("keras_Model.h5", compile=False)

# Load the labels
class_names = open("labels.txt", "r").readlines()

# Create the array of the right shape to feed into the keras model
# The 'length' or number of images you can put into the array is
# determined by the first position in the shape tuple, in this case 1
data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)

# Replace this with the path to your image
image = Image.open("<IMAGE_PATH>").convert("RGB")

# resizing the image to be at least 224x224 and then cropping from the center
size = (224, 224)
image = ImageOps.fit(image, size, Image.Resampling.LANCZOS)

# turn the image into a numpy array
image_array = np.asarray(image)

# Normalize the image
normalized_image_array = (image_array.astype(np.float32) / 127.5) - 1

# Load the image into the array
data[0] = normalized_image_array

# Predicts the model
prediction = model.predict(data)
index = np.argmax(prediction)
class_name = class_names[index]
confidence_score = prediction[0][index]

#Calls for the customer box if face identication matches, if not then prints string on LCD
#What I want to do is centralize all of the functions and only play them after all verifaction methods 
#Have been MET
#1. Make it all under one if statement
#2. Create verification functions that each return true if met 
#I CHOOSE NUMBER TWO
for i in range customerArray: 
    for b in range customerArray
     if prediction == customerArray[i][0]: 
         lcd.write_string("Face Recognized")
         return true
     else: 
        lcd.write_string("Face Does Not Match")
        return false
    
```

# Print prediction and confidence score
print("Class:", class name[2:], end="")
print("Confidence Score:", confidence_score)

[Program Architecture](Program%20Architecture%20306f4794f32280b98d17d4c2df9656a4.md)

# CIRCUIT

[**https://app.cirkitdesigner.com/project/1d811b59-6fc4-4866-a793-75658d77cf7f**](http://url1191.cirkitdesign.com/ls/click?upn=u001.HdQhdwv-2BW1knbvjnTnevC5ABHEiGy4JPLJCpIsr-2FgXKGWB2t3JIvuPp-2BGkvhiZGfIkJAmNowaVCArwzzJRKsXN3AscDAhTGxEBEr5lQq-2FhV9ewsWEHJKEkMQexiRo3Fdq5v4_StYvdz7OkUv4D-2FFfzqm7iQSlL6ITtUL06GswOXO1CmIiNU6-2Bk403GwR8Orvxx8LRGWz-2FPW-2BnJrf-2BlVUWVwNoFndCfJI93N12Jaj91Bi-2FRBlb3jqgCdqXLmEGL-2FnDR1-2BbmuEE-2B4esVjdqP9IZiwKprOCSW1PfP3V3zXoGqGz2ZWm8ydmDOpgJD3g-2Bo8mSVbaK3zpiOmLP5D4dvGDaalJ3Hg-3D-3D)