# Program Architecture

```mermaid
|-> User Logs In 
    |-> Calls on the Box that is theirs from the array 
    |-> 
|-> User Creates a new account 
    |-> Asks for Name 
    |-> Asks for email   
    |-> Asks for Thumbprint 
    |-> Asks for Facial Recognition(Google Teachable machine) 
          |-> Calls on robot to deposit items 
          |-> Button to activate going back response

When testing I should be the old user and Ritvik can be the new user. That way we show the entire function
```